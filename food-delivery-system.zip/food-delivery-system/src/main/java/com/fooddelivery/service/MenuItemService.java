package com.fooddelivery.service;

import com.fooddelivery.model.MenuItem;
import com.fooddelivery.model.Restaurant;
import com.fooddelivery.repository.MenuItemRepository;
import com.fooddelivery.repository.RestaurantRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MenuItemService {

    @Autowired
private RestaurantRepository restaurantRepository;

    @Autowired
    private MenuItemRepository repository;

   public MenuItem saveMenuItem(MenuItem menuItem) {

    MenuItem savedItem = repository.save(menuItem);

    Restaurant restaurant =
            restaurantRepository.findById(menuItem.getRestaurantId())
            .orElse(null);

    if (restaurant != null) {

        if (restaurant.getMenuItems() == null) {
            restaurant.setMenuItems(new ArrayList<>());
        }

        restaurant.getMenuItems().add(savedItem);

        restaurantRepository.save(restaurant);
    }

    return savedItem;
}

    public List<MenuItem> getAllMenuItems() {
        return repository.findAll();
    }

    public MenuItem getMenuItemById(String id) {
        return repository.findById(id).orElse(null);
    }

    public MenuItem updateMenuItem(String id, MenuItem menuItem) {

        MenuItem existingMenuItem = repository.findById(id).orElse(null);

        if (existingMenuItem != null) {
            existingMenuItem.setName(menuItem.getName());
            existingMenuItem.setPrice(menuItem.getPrice());
            existingMenuItem.setDescription(menuItem.getDescription());
            existingMenuItem.setRestaurantId(menuItem.getRestaurantId());

            return repository.save(existingMenuItem);
        }

        return null;
    }

    public String deleteMenuItem(String id) {
        repository.deleteById(id);
        return "Menu Item Deleted Successfully";
    }
}