package com.fooddelivery.service;

import com.fooddelivery.model.Restaurant;
import com.fooddelivery.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepository repository;

    public Restaurant saveRestaurant(Restaurant restaurant) {
        return repository.save(restaurant);
    }

    public List<Restaurant> getAllRestaurants() {
        return repository.findAll();
    }

    public Restaurant getRestaurantById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Restaurant updateRestaurant(String id,
                                       Restaurant restaurant) {

        Restaurant existing =
                repository.findById(id).orElse(null);

        if (existing != null) {
            existing.setName(restaurant.getName());
            existing.setAddress(restaurant.getAddress());
            existing.setPhone(restaurant.getPhone());

            return repository.save(existing);
        }

        return null;
    }

    public String deleteRestaurant(String id) {
        repository.deleteById(id);
        return "Restaurant Deleted Successfully";
    }
}