package com.fooddelivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.model.Customer;
import com.fooddelivery.repository.CustomerRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repository;

    public Customer updateCustomer(String id, Customer customer) {

    Customer existingCustomer = repository.findById(id).orElse(null);

    if (existingCustomer != null) {
        existingCustomer.setName(customer.getName());
        existingCustomer.setEmail(customer.getEmail());
        existingCustomer.setPhone(customer.getPhone());
        existingCustomer.setAddress(customer.getAddress());

        return repository.save(existingCustomer);
    }

    return null;
}

    public String deleteCustomer(String id) {
    repository.deleteById(id);
    return "Customer Deleted Successfully";
}
    public Customer saveCustomer(Customer customer) {
        return repository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public Customer getCustomerById(String id) {
        return repository.findById(id).orElse(null);
    }

    
}