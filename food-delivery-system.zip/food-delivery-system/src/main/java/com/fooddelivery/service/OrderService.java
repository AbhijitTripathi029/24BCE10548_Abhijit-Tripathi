package com.fooddelivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fooddelivery.model.MenuItem;
import com.fooddelivery.model.Order;
import com.fooddelivery.repository.MenuItemRepository;
import com.fooddelivery.repository.OrderRepository;


@Service
public class OrderService {

    @Autowired
    private OrderRepository repository;
    @Autowired
private MenuItemRepository menuItemRepository;
    public Order saveOrder(Order order) {
        return repository.save(order);
    }

        public Order placeOrder(Order order) {

    double total = 0;

    for(String itemId : order.getMenuItemIds()) {

        MenuItem item = menuItemRepository
                .findById(itemId)
                .orElse(null);

        if(item != null) {
            total += item.getPrice();
        }
    }

    order.setTotalAmount(total);
    order.setStatus("PLACED");

    return repository.save(order);
}

    public List<Order> getAllOrders() {
        return repository.findAll();
    }

    public Order getOrderById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Order updateOrder(String id, Order order) {
        order.setId(id);
        return repository.save(order);
    }

    public String deleteOrder(String id) {
        repository.deleteById(id);
        return "Order Deleted Successfully";
    }
}