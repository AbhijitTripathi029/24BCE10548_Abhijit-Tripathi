package com.fooddelivery.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.fooddelivery.model.Order;

@Repository
public interface OrderRepository extends MongoRepository<Order, String> {

}