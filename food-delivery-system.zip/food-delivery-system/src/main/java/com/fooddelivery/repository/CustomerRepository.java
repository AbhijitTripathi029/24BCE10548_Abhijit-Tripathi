package com.fooddelivery.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.fooddelivery.model.Customer;

public interface CustomerRepository extends MongoRepository<Customer, String> {

}