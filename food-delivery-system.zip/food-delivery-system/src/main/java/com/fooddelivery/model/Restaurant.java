package com.fooddelivery.model;
import java.util.List;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.fooddelivery.model.MenuItem;
@Document(collection = "restaurants")
public class Restaurant {

    @Id
    private String id;
    
    private String name;
    private String address;
    private String phone;
@DBRef
private List<MenuItem> menuItems;
    public Restaurant() {
    }
public List<MenuItem> getMenuItems() {
    return menuItems;
}

public void setMenuItems(List<MenuItem> menuItems) {
    this.menuItems = menuItems;
}
    public Restaurant(String name, String address, String phone) {
        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}