package com.fooddelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.fooddelivery.model.Customer;
import com.fooddelivery.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService service;

    @PutMapping("/{id}")
public Customer updateCustomer(@PathVariable String id,
                               @RequestBody Customer customer) {

    return service.updateCustomer(id, customer);
}

    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        return service.saveCustomer(customer);
    }

    
    @GetMapping
    public List<Customer> getAllCustomers() {
        return service.getAllCustomers();
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable String id) {
        return service.getCustomerById(id);
    }

    @DeleteMapping("/{id}")
public String deleteCustomer(@PathVariable String id) {
    return service.deleteCustomer(id);
}

    
}