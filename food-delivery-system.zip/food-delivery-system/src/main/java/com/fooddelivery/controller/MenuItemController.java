package com.fooddelivery.controller;

import com.fooddelivery.model.MenuItem;
import com.fooddelivery.service.MenuItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/menuitems")
public class MenuItemController {

    @Autowired
    private MenuItemService service;

    @PostMapping
    public MenuItem saveMenuItem(@RequestBody MenuItem menuItem) {
        return service.saveMenuItem(menuItem);
    }

    @GetMapping
    public List<MenuItem> getAllMenuItems() {
        return service.getAllMenuItems();
    }

    @GetMapping("/{id}")
    public MenuItem getMenuItemById(@PathVariable String id) {
        return service.getMenuItemById(id);
    }

    @PutMapping("/{id}")
    public MenuItem updateMenuItem(@PathVariable String id,
                                   @RequestBody MenuItem menuItem) {
        return service.updateMenuItem(id, menuItem);
    }

    @DeleteMapping("/{id}")
    public String deleteMenuItem(@PathVariable String id) {
        return service.deleteMenuItem(id);
    }
}