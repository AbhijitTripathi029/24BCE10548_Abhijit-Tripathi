# Online Food Delivery Management System


### Project Description

The Online Food Delivery Management System is a backend-based application developed using Spring Boot and MongoDB as part of the MongoDB course project. The project demonstrates MongoDB integration with Spring Boot, CRUD operations, collection management, relationship mapping, and REST API development.

The application allows management of customers, restaurants, menu items, and food orders through REST APIs. All APIs are tested using Postman and data is stored in MongoDB.

---

## Project Objective

The main objective of this project is to demonstrate the practical implementation of MongoDB concepts through a real-world application.

### Objectives

* MongoDB Database Integration
* CRUD Operations
* Collection Management
* REST API Development
* Spring Boot and MongoDB Connectivity
* Relationship Mapping using MongoDB
* API Testing using Postman

---

## Technologies Used

| Technology          | Version                 |
| ------------------- | ----------------------- |
| Java                | 21                      |
| Spring Boot         | 3.5.15                  |
| MongoDB             | 8.x                     |
| Spring Data MongoDB | Spring Boot Dependency  |
| Maven               | Maven Wrapper           |
| Postman             | API Testing             |
| MongoDB Compass     | Database Management     |
| Visual Studio Code  | Development Environment |

---

## Tools Used

* Visual Studio Code (VS Code)
* MongoDB Compass
* MongoDB Server
* Postman
* Maven

---

## MongoDB Concepts Implemented

### Collections

The project uses the following MongoDB collections:

* customers
* restaurants
* menuitems
* orders

### CRUD Operations

Implemented CRUD operations for all collections:

* Create
* Read
* Update
* Delete

### Relationship Mapping

Implemented relationship mapping using MongoDB @DBRef.

Example:

Restaurant → MenuItem

Relationship Type:

One-to-Many Relationship

Code:

@DBRef
private List<MenuItem> menuItems;

---

## Project Structure

src
├── controller
├── model
├── repository
├── service
└── resources

### Architecture

Controller Layer

       ↓

Service Layer

       ↓

Repository Layer

       ↓

MongoDB Database

---

## Database Configuration

### Database Name

food_delivery_db

### MongoDB Connection URL

mongodb://localhost:27017/food_delivery_db

---

## REST APIs

### Customer APIs

| Method | Endpoint        |
| ------ | --------------- |
| POST   | /customers      |
| GET    | /customers      |
| GET    | /customers/{id} |
| PUT    | /customers/{id} |
| DELETE | /customers/{id} |

### Restaurant APIs

| Method | Endpoint          |
| ------ | ----------------- |
| POST   | /restaurants      |
| GET    | /restaurants      |
| GET    | /restaurants/{id} |
| PUT    | /restaurants/{id} |
| DELETE | /restaurants/{id} |

### Menu Item APIs

| Method | Endpoint        |
| ------ | --------------- |
| POST   | /menuitems      |
| GET    | /menuitems      |
| GET    | /menuitems/{id} |
| PUT    | /menuitems/{id} |
| DELETE | /menuitems/{id} |

### Order APIs

| Method | Endpoint     |
| ------ | ------------ |
| POST   | /orders      |
| GET    | /orders      |
| GET    | /orders/{id} |
| PUT    | /orders/{id} |
| DELETE | /orders/{id} |

---

## Running the Project

### Prerequisites

* Java 21
* MongoDB Server
* Maven
* Postman

### Run Application

Open terminal in project root folder:

```powershell
.\mvnw.cmd spring-boot:run
```

Application will start on:
http://localhost:8080

---

## Testing

The application is tested using Postman.

### Tested Modules

* Customer CRUD Operations
* Restaurant CRUD Operations
* Menu Item CRUD Operations
* Order CRUD Operations

MongoDB Compass is used to verify stored documents and collections.

---

## Screenshots

The repository includes screenshots for:

* Project Structure
* Application Running
* MongoDB Collections
* Customer API Testing
* Restaurant API Testing
* Menu Item API Testing
* Order API Testing

---

## Learning Outcomes

Through this project, the following MongoDB concepts were implemented:

* MongoDB Collections
* Document-Based Data Storage
* CRUD Operations
* Spring Data MongoDB
* Repository Pattern
* REST API Integration
* Relationship Mapping using @DBRef
* MongoDB Compass Usage

---

## Conclusion

This project successfully demonstrates MongoDB integration with Spring Boot through a real-world Online Food Delivery Management System. The application performs CRUD operations on multiple collections, stores data in MongoDB, implements relationship mapping, and exposes REST APIs tested through Postman. The project fulfills the requirements of the MongoDB course project and demonstrates practical knowledge of MongoDB and Spring Boot development.
